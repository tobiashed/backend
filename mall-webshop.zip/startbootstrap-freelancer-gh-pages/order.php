<!DOCTYPE html>
<html lang="en">

  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Order</title>

    <!-- Bootstrap core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom fonts for this template -->
    <link href="vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Lato:400,700,400italic,700italic" rel="stylesheet" type="text/css">

    <!-- Plugin CSS -->
    <link href="vendor/magnific-popup/magnific-popup.css" rel="stylesheet" type="text/css">

    <!-- Custom styles for this template -->
    <link href="css/freelancer.min.css" rel="stylesheet">

  </head>

  <body id="page-top">

    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg bg-secondary fixed-top text-uppercase" id="mainNav">
      <div class="container">
        <a class="navbar-brand js-scroll-trigger" href="index.php#page-top">Webshop</a>
        <button class="navbar-toggler navbar-toggler-right text-uppercase bg-primary text-white rounded" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
          Meny
          <i class="fa fa-bars"></i>
        </button>
        <div class="collapse navbar-collapse" id="navbarResponsive">
          <ul class="navbar-nav ml-auto">
            <li class="nav-item mx-0 mx-lg-1">
              <a class="nav-link py-3 px-0 px-lg-3 rounded js-scroll-trigger" href="index.php#portfolio">Produkter</a>
            </li>
            <li class="nav-item mx-0 mx-lg-1">
              <a class="nav-link py-3 px-0 px-lg-3 rounded js-scroll-trigger" href="index.php#about">Om oss</a>
            </li>
            <li class="nav-item mx-0 mx-lg-1">
              <a class="nav-link py-3 px-0 px-lg-3 rounded js-scroll-trigger" href="index.php#contact">Kontakt</a>
            </li>
          </ul>
        </div>
      </div>
    </nav>

    <!-- Header -->
    <header class="masthead bg-primary text-white text-center">
      <div class="container">
        <img class="img-fluid mb-5 d-block mx-auto" src="img/profile.png" alt="">
        <h1 class="text-uppercase mb-0">Välkommen till vår webshop!</h1>
        <hr class="star-light">
        <h2 class="font-weight-light mb-0">Antikt - Vintage - Retro</h2>
      </div>
    </header>

    <!-- Portfolio Grid Section -->
    <section class="portfolio" id="portfolio">
      <div class="container">
        <h2 class="text-center text-uppercase text-secondary mb-0">Beställning</h2>
        <hr class="star-dark mb-5">
        <?php
    require_once('connect.php');
    // Hämta data från $_GET
    if(isset($_GET['prodID']) ){
        $prodID = htmlspecialchars($_GET['prodID']);
        // Förbered en SQL-sats som hämtar all data tillhörande vald produkt från tabellen produkt i databasen
        $sql = "SELECT * FROM produkt WHERE artikelnr = $prodID";
        // Exekvera SQL-satsen
        $table = mysqli_query($connection, $sql) or die(mysqli_error($connection));
        
        
        $row = $table->fetch_assoc();


        // Skapa ett formulär som även hämtar produktnamn och pris till readonly-fält i formuläret
        // samt artikelnr som "hidden value"
        echo "<form action='orderConfirmation.php#portfolio' method='post'>
                <input type='hidden' name='artikelnr' value=" .  $row['artikelnr']  . ">
                <h2>Din order: </h2>
                <br>
                <div class='form-row'>
                    <div class='form-group col-sm-6'>
                        <label for='produkt'>Vald produkt</label>
                        <input type='text' readonly class='form-control' id='produkt' name='produkt' value=' " . $row['namn']  . "
                        '>
                    </div>
                    <div class='form-group col-sm-6'>
                        <label for='pris'>Pris i kr</label>
                        <input type='text' readonly class='form-control' id='pris' name='pris' value=' " . $row['pris'] . " '>
                    </div>       
                </div>
                <div class='form-row'>
                    <div class='form-group col-sm-6'>
                        <label for='yourFname'>Förnamn</label>
                        <input type='text' class='form-control' id='yourFname' name='yourFname' placeholder='Förnamn' required>
                    </div>
                    <div class='form-group col-sm-6'>
                        <label for='yourLname'>Efternamn</label>
                        <input type='text' class='form-control' id='yourLname' name='yourLname' placeholder='Efternamn' required>
                    </div>
                </div>
                <div class='form-row'>
                    <div class='form-group col-sm-4'>
                        <label for='yourPhone'>Telefon</label>
                        <input type='tel' pattern='^[0-9\-\+\s]*$' title='Nummer (0-9), bindestreck -, plus +, och mellanslag är tillåtet.' class='form-control' id='yourPhone' name='yourPhone' placeholder='Telefon' required>
                    </div>
                    <div class='form-group col-sm-8'>
                        <label for='yourEmail'>E-mail</label>
                        <input type='email' class='form-control' id='yourEmail' name='yourEmail' placeholder='E-mail' required>
                    </div>
                </div>
                <div class='form-row'>
                    <div class='form-group col-sm-6'>
                        <label for='yourAddress'>Adress</label>
                        <input type='text' class='form-control' id='yourAddress' name='yourAddress' placeholder='Gatuadress' required>
                        <small id='passwordHelpBlock' class='form-text text-muted'>
                            * Samtliga fält måste fyllas i för att beställning ska kunna genomföras
                        </small>
                    </div>
                    <div class='form-group col-sm-4'>
                        <label for='yourCity'>Stad</label>
                        <input type='text' class='form-control' id='yourCity' name='yourCity' placeholder='Stad' required>
                    </div>
                    <div class='form-group col-sm-2'>
                        <label for='yourZip'>Postnr</label>
                        <input type='text' class='form-control' id='yourZip' name='yourZip' placeholder='Postnr' required>
                    </div>
                </div>
                <div class='form-group row'>
                    <div class='col-sm-12'>
                        <input type='reset' value='Rensa' class='btn btn-primary'>
                        <button type='submit' class='btn btn-primary'>Skicka beställning</button>
                    </div>
                </div>
            </form>";

  
       
    }
    else{
        // Om en person går in på ordersidan utan att välja en produkt på startsidan visas ett felmeddelande
        echo "<p class='alert alert-danger'>OBS! Du måste välja en produkt innan beställningen kan utföras</p>";
        echo "<a href='index.php' class='btn btn-danger btn-block'>Till startsidan</a>";
    }
?>
        
        
    </section>

    
   

    <!-- Footer -->
    <footer class="footer text-center">
      <div class="container">
        <div class="row">
          <div class="col-md-4 mb-5 mb-lg-0">
            <h4 class="text-uppercase mb-4">Location</h4>
            <p class="lead mb-0">2215 John Daniel Drive
              <br>Clark, MO 65243</p>
          </div>
          <div class="col-md-4 mb-5 mb-lg-0">
            <h4 class="text-uppercase mb-4">Around the Web</h4>
            <ul class="list-inline mb-0">
              <li class="list-inline-item">
                <a class="btn btn-outline-light btn-social text-center rounded-circle" href="#">
                  <i class="fa fa-fw fa-facebook"></i>
                </a>
              </li>
              <li class="list-inline-item">
                <a class="btn btn-outline-light btn-social text-center rounded-circle" href="#">
                  <i class="fa fa-fw fa-google-plus"></i>
                </a>
              </li>
              <li class="list-inline-item">
                <a class="btn btn-outline-light btn-social text-center rounded-circle" href="#">
                  <i class="fa fa-fw fa-twitter"></i>
                </a>
              </li>
              <li class="list-inline-item">
                <a class="btn btn-outline-light btn-social text-center rounded-circle" href="#">
                  <i class="fa fa-fw fa-linkedin"></i>
                </a>
              </li>
              <li class="list-inline-item">
                <a class="btn btn-outline-light btn-social text-center rounded-circle" href="#">
                  <i class="fa fa-fw fa-dribbble"></i>
                </a>
              </li>
            </ul>
          </div>
          <div class="col-md-4">
            <h4 class="text-uppercase mb-4">About Freelancer</h4>
            <p class="lead mb-0">Freelance is a free to use, open source Bootstrap theme created by
              <a href="http://startbootstrap.com">Start Bootstrap</a>.</p>
          </div>
        </div>
      </div>
    </footer>

    <div class="copyright py-4 text-center text-white">
      <div class="container">
        <small>Copyright &copy; Your Website 2018</small>
      </div>
    </div>

    <!-- Scroll to Top Button (Only visible on small and extra-small screen sizes) -->
    <div class="scroll-to-top d-lg-none position-fixed ">
      <a class="js-scroll-trigger d-block text-center text-white rounded" href="#page-top">
        <i class="fa fa-chevron-up"></i>
      </a>
    </div>

    

    <!-- Bootstrap core JavaScript -->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Plugin JavaScript -->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>
    <script src="vendor/magnific-popup/jquery.magnific-popup.min.js"></script>

    <!-- Contact Form JavaScript -->
    <script src="js/jqBootstrapValidation.js"></script>
    <script src="js/contact_me.js"></script>

    <!-- Custom scripts for this template -->
    <script src="js/freelancer.min.js"></script>

  </body>

</html>
