<!DOCTYPE html>
<html lang="en">

  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Order</title>

    <!-- Bootstrap core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom fonts for this template -->
    <link href="vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Lato:400,700,400italic,700italic" rel="stylesheet" type="text/css">

    <!-- Plugin CSS -->
    <link href="vendor/magnific-popup/magnific-popup.css" rel="stylesheet" type="text/css">

    <!-- Custom styles for this template -->
    <link href="css/freelancer.min.css" rel="stylesheet">

  </head>

  <body id="page-top">

    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg bg-secondary fixed-top text-uppercase" id="mainNav">
      <div class="container">
        <a class="navbar-brand js-scroll-trigger" href="index.php#page-top">Webshop</a>
        <button class="navbar-toggler navbar-toggler-right text-uppercase bg-primary text-white rounded" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
          Meny
          <i class="fa fa-bars"></i>
        </button>
        <div class="collapse navbar-collapse" id="navbarResponsive">
          <ul class="navbar-nav ml-auto">
            <li class="nav-item mx-0 mx-lg-1">
              <a class="nav-link py-3 px-0 px-lg-3 rounded js-scroll-trigger" href="index.php#portfolio">Produkter</a>
            </li>
            <li class="nav-item mx-0 mx-lg-1">
              <a class="nav-link py-3 px-0 px-lg-3 rounded js-scroll-trigger" href="index.php#about">Om oss</a>
            </li>
            <li class="nav-item mx-0 mx-lg-1">
              <a class="nav-link py-3 px-0 px-lg-3 rounded js-scroll-trigger" href="index.php#contact">Kontakt</a>
            </li>
          </ul>
        </div>
      </div>
    </nav>

    <!-- Header -->
    <header class="masthead bg-primary text-white text-center">
      <div class="container">
        <img class="img-fluid mb-5 d-block mx-auto" src="img/profile.png" alt="">
        <h1 class="text-uppercase mb-0">Välkommen till vår webshop!</h1>
        <hr class="star-light">
        <h2 class="font-weight-light mb-0">Antikt - Vintage - Retro</h2>
      </div>
    </header>

    <!-- Portfolio Grid Section -->
    <section class="portfolio" id="portfolio">
      <div class="container">
        <h2 class="text-center text-uppercase text-secondary mb-0">Beställningsbekräftelse</h2>
        <hr class="star-dark mb-5">
        <?php
// Funktion för validering av formuläret
function check_input($data)
{
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}
?>

<?php

// Logga in i databasen
require_once('connect.php');

// Hämta data från $_POST-arrayen

if(isset($_POST['artikelnr']) && isset($_POST['yourFname']) && isset($_POST['yourLname']) && isset($_POST['yourPhone']) 
&& isset($_POST['yourEmail']) && isset($_POST['yourAddress']) && isset($_POST['yourCity']) && isset($_POST['yourZip'])){
    if(empty($_POST['artikelnr']) || empty($_POST['yourFname']) || empty($_POST['yourLname']) || empty($_POST['yourPhone']) 
    || empty($_POST['yourEmail']) || empty($_POST['yourAddress']) || empty($_POST['yourCity']) || empty($_POST['yourZip'])){
    
        // Om en person inte fyller i samtliga fält på ordersidan visas ett felmeddelande
        echo "<p class='alert alert-danger'>OBS! Du måste fylla i samtliga fält i orderformuläret innan bekräftelsen kan visas</p>";
        echo "<a href='index.php' class='btn btn-danger btn-block'>Till startsidan</a>";
    
    }
    else{
        // Anropa funktionen check_input
        $product = check_input($_POST['produkt']);
        $price = check_input($_POST['pris']);
        $article = check_input($_POST['artikelnr']);
        $fname = check_input($_POST['yourFname']);
        $lname = check_input($_POST['yourLname']);
        $phone = check_input($_POST['yourPhone']);
        $mail = check_input($_POST['yourEmail']);
        $address = check_input($_POST['yourAddress']);
        $city = check_input($_POST['yourCity']);
        $zip = check_input($_POST['yourZip']);
    
    
        // Förbered en SQL-sats som lägger till en ny post i tabellen beställning i databasen
        $sql= "INSERT INTO bestallning (produkt, fornamn, efternamn, telefon, epost, adress, postnr, stad, orderdatum) 
        VALUES ('$article','$fname', '$lname', '$phone', '$mail', '$address', '$zip', '$city', CURRENT_TIMESTAMP)";
    
        // Exekvera SQL-satsen
        mysqli_query($connection, $sql) or die(mysqli_error($connection));
    
        // Skriv ut orderbekräftelse
        echo "<h6>Din order har skickats!</h6>";
        echo "<table class='table'>";
        echo "<thead><tr>
        <th scope='col'>Datum</th>
        <th scope='col'>Produkt</th>
        <th scope='col'>Pris</th>
        </tr></thead>
        <tbody><tr>
        <td>" . date("Y-m-d") . "</td>
        <td>$product</td>
        <td>$price</td>
        </tr></tbody>
        </table>";
      
        echo "<div class='row'><div class='col-sm-6'>
        <ul class='list-unstyled'><strong>Leveransadress:</strong>
        <li>$fname $lname</li>
        <li>$address</li>
        <li>$zip $city</li>
        </ul></div>";
        echo "<div class='col-sm-6'>
        <ul class='list-unstyled'><strong>Kontaktuppgifter:</strong>
        <li>$mail</li>
        <li>$phone</li>
        </ul></div></div>";
        echo "<a href='index.php' class='btn btn-primary btn-block'>Tillbaka till startsidan</a>";
    }
} else{
    // Om en person går in på ordersidan utan att välja en produkt på startsidan visas ett felmeddelande
    echo "<p class='alert alert-danger'>OBS! Du måste välja en produkt innan beställningen kan utföras</p>";
    echo "<a href='index.php' class='btn btn-danger btn-block'>Till startsidan</a>";
}

?>
        
        
    </section>

    
   

    <!-- Footer -->
    <footer class="footer text-center">
      <div class="container">
        <div class="row">
          <div class="col-md-4 mb-5 mb-lg-0">
            <h4 class="text-uppercase mb-4">Location</h4>
            <p class="lead mb-0">2215 John Daniel Drive
              <br>Clark, MO 65243</p>
          </div>
          <div class="col-md-4 mb-5 mb-lg-0">
            <h4 class="text-uppercase mb-4">Around the Web</h4>
            <ul class="list-inline mb-0">
              <li class="list-inline-item">
                <a class="btn btn-outline-light btn-social text-center rounded-circle" href="#">
                  <i class="fa fa-fw fa-facebook"></i>
                </a>
              </li>
              <li class="list-inline-item">
                <a class="btn btn-outline-light btn-social text-center rounded-circle" href="#">
                  <i class="fa fa-fw fa-google-plus"></i>
                </a>
              </li>
              <li class="list-inline-item">
                <a class="btn btn-outline-light btn-social text-center rounded-circle" href="#">
                  <i class="fa fa-fw fa-twitter"></i>
                </a>
              </li>
              <li class="list-inline-item">
                <a class="btn btn-outline-light btn-social text-center rounded-circle" href="#">
                  <i class="fa fa-fw fa-linkedin"></i>
                </a>
              </li>
              <li class="list-inline-item">
                <a class="btn btn-outline-light btn-social text-center rounded-circle" href="#">
                  <i class="fa fa-fw fa-dribbble"></i>
                </a>
              </li>
            </ul>
          </div>
          <div class="col-md-4">
            <h4 class="text-uppercase mb-4">About Freelancer</h4>
            <p class="lead mb-0">Freelance is a free to use, open source Bootstrap theme created by
              <a href="http://startbootstrap.com">Start Bootstrap</a>.</p>
          </div>
        </div>
      </div>
    </footer>

    <div class="copyright py-4 text-center text-white">
      <div class="container">
        <small>Copyright &copy; Your Website 2018</small>
      </div>
    </div>

    <!-- Scroll to Top Button (Only visible on small and extra-small screen sizes) -->
    <div class="scroll-to-top d-lg-none position-fixed ">
      <a class="js-scroll-trigger d-block text-center text-white rounded" href="#page-top">
        <i class="fa fa-chevron-up"></i>
      </a>
    </div>

    

    <!-- Bootstrap core JavaScript -->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Plugin JavaScript -->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>
    <script src="vendor/magnific-popup/jquery.magnific-popup.min.js"></script>

    <!-- Contact Form JavaScript -->
    <script src="js/jqBootstrapValidation.js"></script>
    <script src="js/contact_me.js"></script>

    <!-- Custom scripts for this template -->
    <script src="js/freelancer.min.js"></script>

  </body>

</html>
