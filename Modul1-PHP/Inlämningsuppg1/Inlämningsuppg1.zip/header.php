<!DOCTYPE html>
<html lang="sv">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <!-- Lägg till ikon i webbläsarfönstrets flik -->
    <link rel="shortcut icon" href="bilder/logo.png" />
    <title><?=PAGE_TITLE?></title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <style>
    footer{
        text-align: center;
    }
    </style>
</head>
<body class="container">

<!-- Jumbotron -->
    <div class="jumbotron">
        <div class="text-center">
            <h1>Välkommen till vår webshop</h1>
        </div>
    </div>