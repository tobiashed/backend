    <hr>
    <footer class="bg-light">
        Tobias Webshop
        &bull; 08-12 34 56
        &bull; Storgatan 1, 123 45 Stockholm
        <br>
        Copyright &copy; <?php echo date("Y"); ?> 
    </footer>
</body>
</html>