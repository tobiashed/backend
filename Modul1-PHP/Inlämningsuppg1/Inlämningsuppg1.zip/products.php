<?php
// Skapa en associative array med produkter
$products = array (
    "P001" => array ("id" => "P001" , "name" => "iPhone 8 64 GB" , "price" => "8000" , "img" =>"iphone8.jpg"), 
    "P002" => array ("id" => "P002" , "name" => "iPhone X 64 GB" , "price" => "11000" ,"img" => "iphonex.jpg"), 
    "P003" => array ("id" => "P003" , "name" => "iPhone X 256 GB" ,"price" =>  "13500" , "img" => "iphonex2.jpg") 
);
?>

